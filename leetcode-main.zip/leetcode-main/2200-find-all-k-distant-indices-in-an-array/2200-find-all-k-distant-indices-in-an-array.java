class Solution {
    public List<Integer> findKDistantIndices(int[] nums, int key, int k) {
        List<Integer> ans = new ArrayList<>();

        int[] arr = new int[nums.length];
        int dist = 0;

        for (int i = 0; i < Math.min(k, arr.length); i++) {
            if (nums[i] == key) dist = i + k + 1;
        }

        for (int i = 0; i < arr.length; i++) {
            if (i + k < arr.length && nums[i + k] == key) dist = 2 * k + 1;
            if (dist > 0){
                arr[i]++;
                dist--;
            }
        }

        for (int i = 0; i < arr.length; i++)
            if (arr[i] > 0)
                ans.add(i);
				
		return ans;
    }
}