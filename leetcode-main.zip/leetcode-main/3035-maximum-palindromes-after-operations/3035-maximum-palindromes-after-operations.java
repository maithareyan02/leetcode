class Solution {
    public int maxPalindromesAfterOperations(String[] words) {
        int n=words.length;
        HashMap<Character,Integer> map=new HashMap<>();
        for(int i=0;i<n;i++){
            for(int j=0;j<words[i].length();j++){
                map.put(words[i].charAt(j),map.getOrDefault(words[i].charAt(j),0)+1);
            }
        }
        int []arr=new int[n];
        for(int i=0;i<n;i++){
            arr[i]=words[i].length();
        }
        int ans=0;
        Arrays.sort(arr);
        int temp=0;
        for(char a:map.keySet()) {
            if(map.get(a)>=2){
                temp+=map.get(a)/2;
            }
        }
        for(int i=0;i<n;i++){
            if(arr[i]/2<=temp){
                temp-=arr[i]/2;
                ans++;
            }else{
                break;
            }
        }
        return ans;
    }
}